
public class InteriorCell {

}
