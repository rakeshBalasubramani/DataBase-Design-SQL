
public abstract class Page {
	
	
	private void readTinyInt()
	{
		
	}
	
	private void writeTinyInt()
	{
		
	}
	
	private void readSmallInt()
	{
		
	}
	
	private void writeSmallInt()
	{
		
	}
	
	
	private void readInt()
	{
		
	}
	
	private void writeInt()
	{
		
	}
	
	
	private void readBigInt()
	{
		
	}
	
	private void writeBigInt()
	{
		
	}
	
	
	
	private void readReal()
	{
		
	}
	
	private void writeReal()
	{
		
	}
	
	
	private void readDouble()
	{
		
	}
	
	private void writeDouble()
	{
		
	}
	
	
	private void readDateTime()
	{
		
	}
	
	private void writeDateTime()
	{
		
	}
	
	private void readDate()
	{
		
	}
	
	private void writeDate()
	{
		
	}
	
	
	private void readText()
	{
		
	}
	
	private void writeText()
	{
		
	}
	

}
