
public class InteriorPage extends Page {
	

}
