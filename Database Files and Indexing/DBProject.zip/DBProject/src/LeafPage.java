
public class LeafPage extends Page {

}
